<?php
namespace NitroPack\SDK\StorageDriver;

use \NitroPack\SDK\FileHandle;

class RedisFileHandle extends FileHandle {}
